//Remember, this module is cached as it has already been loaded
const express = require('express');
let router = express.Router();

//Note: these paths are relative to where the router is mounted
//Since it is mounted to /users in the main app
//These URLs represent the part AFTER /users
router.get("/", function(req,res,next){ res.send("GET /users"); });

//You can define callback functions to be executed
// if a particular parameter is part of the route.
//In this case, whenever a parameter :uid is in the route
// we create a user property and give it an id.
//In general, this could load the user's information,
// since we are generally about to do something with that user
router.param("uid", function(req, res, next, uid){
	req.user = {id: uid}
	//Note, if the user is not found, you could send a 404 instead of next()
	next();
});

//Define a route for a specific user, based on ID
//Since :uid is in the parameters, the above function will
// have initiated a user object with an id property
router.get("/:uid", function(req,res,next){ 
	res.send("GET /users/" + req.params.uid + " " + req.user.id); 
});

//Can create another router, which is a sub-router to this router
//Can nest in folder structure, again allowing for more organization
//Since :uid is in the parameters, the above function will
// have initiated a user object with an id property
//In this case, we need this, as there will not be a :uid
// parameter in the sub-router
const friendsRouter = require("./friends-router.js");
router.use("/:uid/friends", friendsRouter);

module.exports = router;