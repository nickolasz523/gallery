const express = require('express');
let router = express.Router();

router.get("/", function(req,res,next){ res.send("GET /products"); });
router.get("/:pid", respondProduct)

function respondProduct(req, res, next){
	res.send("GET /products/" + req.params.pid);
}

module.exports = router;