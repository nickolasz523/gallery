//Remember, this module is cached as it has already been loaded
const express = require('express');

//Create the router for the base route /users/friends
let router = express.Router();

//Note: these paths are relative to where the router is mounted
//So these represent /users/:uid/friends/ and /users/:uid/friends/:fid
//Also note that, since :uid is not part of the route here, you can't access it directly
//Instead, here we reference the user property of the request
// created in the users-router.js module
router.get("/", function(req,res,next){ res.send("GET /users/" + req.user.id + "/friends/"); });
router.get("/:fid", function(req,res,next){ 
	res.send("GET /users/" + req.user.id + "/friends/" + req.params.fid); 
});

module.exports = router;