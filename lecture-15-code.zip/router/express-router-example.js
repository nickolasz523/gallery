
const express = require('express');
const app = express();

const usersRouter = require("./users-router");
const productsRouter = require("./products-router");

//Mount the usersRouter router to the path /users
//All requests starting with /users will be forwarded to this router
app.use("/users", usersRouter);
//Do the same with productsRouter
app.use("/products", productsRouter);

//Handle a single request here
app.get("/", function(req, res, next){ res.send("Home Page!") });

app.listen(3000);
console.log("Server running at http://localhost:3000");